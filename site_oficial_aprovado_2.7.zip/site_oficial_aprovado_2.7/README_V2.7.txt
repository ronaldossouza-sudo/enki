ENKI INFRA — SITE OFICIAL V2.7

Base oficial: site_oficial_aprovado_2.6.

Alteração única:
- removido o formulário de contato que abria o aplicativo de e-mail;
- mantido o bloco visual de atendimento;
- adicionados atalhos diretos para WhatsApp e e-mail;
- removida do JavaScript a rotina do formulário/mailto automático.

Todo o restante do site V2.6 foi preservado.
Nenhuma alteração em Portal, AWS, Nginx, DNS ou backend.
