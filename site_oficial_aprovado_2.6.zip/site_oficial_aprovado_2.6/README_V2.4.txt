ENKI INFRA — SITE V2.4

Base:
- Construído sobre a V2.3 revisada aprovada, que preserva o layout da V2.1.
- Não houve reconstrução dos grids, hero ou disposição das imagens.

Identidade V2.4:
- Novo símbolo abstrato em formato de E, inspirado no conceito aprovado.
- Gradiente teal/cyan + azul profundo.
- Wordmark ENKI em grafite no cabeçalho branco.
- Divisor vertical entre símbolo e wordmark.
- INFRA espaçado e assinatura “TECNOLOGIA QUE CONECTA SEU NEGÓCIO”.
- Versão branca específica para o rodapé.
- Novo favicon derivado do símbolo.
- Imagem conceitual aprovada incluída em assets/img/brand/referencia-logo-v2.4.png.

Cabeçalho:
- Fundo branco.
- Início, Soluções, Sobre a ENKI, Contato e Portal do Cliente em preto.
- Hover/ativo em teal.

Segurança:
- Pacote estático.
- Não contém banco de dados, certificados, tokens ou senhas.
- Não altera Portal, AWS, Nginx ou DNS.
