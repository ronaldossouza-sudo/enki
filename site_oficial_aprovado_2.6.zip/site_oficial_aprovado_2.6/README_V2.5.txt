ENKI INFRA — SITE V2.5

Base: V2.4.

Alteração solicitada:
- O rodapé NÃO carrega mais assets/img/brand/logo-footer.svg.
- O rodapé agora carrega assets/img/brand/logo-footer.png.
- logo-footer.png foi incluído em assets/img/brand/.
- O restante do layout e identidade da V2.4 foi preservado.
- O logo SVG original foi mantido apenas como arquivo-fonte; não é usado pelo rodapé.

Segurança:
- Pacote estático.
- Não contém banco de dados, certificados, tokens ou senhas.
- Não altera Portal, AWS, Nginx ou DNS.
