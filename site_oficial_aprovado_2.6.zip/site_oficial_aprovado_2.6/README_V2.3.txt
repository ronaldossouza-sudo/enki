ENKI INFRA — V2.3 REVISADA

- Reconstruída diretamente sobre a V2.1 aprovada.
- Layout, posicionamento e estrutura das imagens da V2.1 preservados.
- Cabeçalho alterado para fundo branco.
- Nova identidade ENKI INFRA aplicada somente aos elementos de marca.
- Logo do cabeçalho: ENKI escuro para fundo branco.
- Logo do rodapé: ENKI branco para fundo escuro.
- Paleta teal/grafite aplicada sem reconstruir grids/hero.
- Não contém banco, credenciais, certificados ou configuração do Portal.
- Não altera AWS, Nginx ou DNS.

- Revisão adicional: textos Início, Soluções, Sobre a ENKI, Contato e Portal do Cliente em preto/grafite no cabeçalho branco.
- Hover/foco/estado ativo em teal #14A090.
- Regra aplicada também à navegação responsiva/mobile.
