ENKI INFRA — SITE V2.6 / IDENTIDADE EM PNG

Base: V2.5.

Padronização solicitada:
- logo-header.png
- logo-footer.png
- symbol.png
- favicon.png

Todas as referências de identidade visual no HTML foram alteradas para PNG.
Os SVGs foram mantidos somente como arquivos-fonte de segurança e não são necessários para o carregamento normal da identidade no site.

Layout, textos, imagens das seções, cabeçalho branco e menu preto da versão anterior foram preservados.

Pacote estático: sem banco, certificados, tokens ou senhas.
Nenhuma alteração em Portal, AWS, Nginx ou DNS.
