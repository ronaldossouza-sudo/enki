ENKI INFRA — SITE V2.1
===========================

Base: V2 aprovada visualmente.

Alterações desta revisão:
- reconstrução completa dos arquivos vetoriais da marca;
- símbolo sem auto-interseções ou sobreposições incorretas;
- logo horizontal para fundo claro e fundo escuro;
- favicon novo;
- rodapé atualizado para usar a mesma identidade real;
- CSS protegido contra distorção de proporção;
- nenhuma mudança de estrutura/layout aprovado;
- nenhuma alteração em AWS, DNS, Nginx ou Portal.

Arquivos principais:
- index.html
- assets/css/styles.css
- assets/js/main.js
- assets/img/enki-logo-light.svg
- assets/img/enki-logo-dark.svg
- assets/img/enki-mark.svg
- assets/img/favicon.svg

Teste local:
1. Extraia o ZIP.
2. Abra index.html no navegador, ou
3. Execute "python -m http.server 8080" dentro da pasta e acesse localhost:8080.
