ENKI INFRA — PORTAL DO CLIENTE V3.0 — PACOTE DE PRODUÇÃO
=========================================================

ESCOPO
- Modernização visual/UX do Portal do Cliente.
- Mantém portal_v2.py como APIRouter.
- Preserva decoradores/rotas existentes.
- Preserva consultas e URLs de NFS-e PDF/XML e orçamentos na página do cliente.
- Não contém portal.db, storage, documentos, certificados, tokens ou credenciais.
- O logotipo é o PNG oficial da identidade ENKI INFRA V2.7.

IMPORTANTE
Este pacote NÃO traz um portal_v2.py completo fabricado fora do servidor.
O atualizador lê o portal_v2.py que já está em produção e troca somente:
  _brand_mark
  _base_css
  landing_page_response
  client_page
Antes de gerar o novo arquivo, valida a estrutura esperada. Depois, confere que a lista de decoradores/rotas permaneceu idêntica e compila o Python.

PASSO 1 — enviar e extrair
Exemplo:
  cd /tmp
  unzip ENKI_PORTAL_V3_PRODUCAO.zip -d ENKI_PORTAL_V3_PRODUCAO

PASSO 2 — gerar e validar, SEM reiniciar
  cd /tmp/ENKI_PORTAL_V3_PRODUCAO
  sudo bash APLICAR_SEM_REINICIAR.sh

O script cria:
- backup de portal_v2.py;
- checkpoint local de data/portal.db, se existir;
- /opt/rtech-portal/portal_v2.py.v3.new;
- validação com py_compile;
- validação de que decoradores/rotas não mudaram.

PASSO 3 — revisão rápida antes de instalar
  sudo diff -u /opt/rtech-portal/portal_v2.py /opt/rtech-portal/portal_v2.py.v3.new | less

PASSO 4 — instalar somente se PASSO 2 terminar com "VALIDADO"
  sudo cp /opt/rtech-portal/portal_v2.py.v3.new /opt/rtech-portal/portal_v2.py
  sudo systemctl restart rtech-portal.service

PASSO 5 — validação imediata
  sudo systemctl status rtech-portal.service --no-pager
  curl -fsS http://127.0.0.1:8000/health
  curl -I https://nfse.enkiinfra.com/

Depois, no navegador:
- abrir a home do Portal;
- abrir um link /c/<token> JÁ EXISTENTE;
- confirmar que lista somente documentos do cliente correto;
- abrir PDF de uma NFS-e já publicada;
- abrir XML de uma NFS-e já publicada;
- abrir PDF de um orçamento já publicado;
- validar desktop e celular.
NÃO emitir nem reenviar NFS-e para testar a interface.

ROLLBACK
O caminho exato do backup é impresso pelo script. Exemplo:
  sudo cp /opt/rtech-portal/backups/pre_portal_v3_YYYYMMDD_HHMMSS/portal_v2.py /opt/rtech-portal/portal_v2.py
  sudo systemctl restart rtech-portal.service
  curl -fsS http://127.0.0.1:8000/health

O checkpoint portal.db.backup é apenas proteção adicional e NÃO deve ser restaurado em rollback visual, salvo incidente separado e deliberadamente diagnosticado.
