#!/usr/bin/env bash
set -euo pipefail
BASE=/opt/rtech-portal
SRC="$BASE/portal_v2.py"
PKG_DIR="$(cd "$(dirname "$0")" && pwd)"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP="$BASE/backups/pre_portal_v3_$STAMP"
NEW="$BASE/portal_v2.py.v3.new"

cd "$BASE"
[ -f "$SRC" ] || { echo "ERRO: $SRC não encontrado"; exit 1; }
mkdir -p "$BACKUP"
cp -a "$SRC" "$BACKUP/portal_v2.py"
# Checkpoint opcional do DB no servidor; nunca é incluído no pacote.
if [ -f "$BASE/data/portal.db" ]; then cp -a "$BASE/data/portal.db" "$BACKUP/portal.db.backup"; fi

python3 "$PKG_DIR/portal_v3_patch.py" --source "$SRC" --output "$NEW" --logo "$PKG_DIR/assets/logo-header.png"
python3 -m py_compile "$NEW"

echo ""
echo "VALIDADO. Nenhum serviço foi reiniciado."
echo "Backup: $BACKUP"
echo "Novo arquivo: $NEW"
echo "Para instalar após revisão:"
echo "  sudo cp '$NEW' '$SRC'"
echo "  sudo systemctl restart rtech-portal.service"
echo "  curl -fsS http://127.0.0.1:8000/health"
